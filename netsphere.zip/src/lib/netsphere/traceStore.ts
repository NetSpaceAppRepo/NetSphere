'use client'

import { create } from 'zustand'
import { io, Socket } from 'socket.io-client'
import type { GeoInfo, Hop, TraceResult, TraceStatus } from './types'
import { DEFAULT_USER_ORIGIN } from './types'

const TRACE_PORT = 3003
const HISTORY_STORAGE_KEY = 'netsphere-history-v1'
const MAX_HISTORY = 20

// Detect sandbox mode: in the sandbox, the page is served through Caddy on
// port 81 with XTransformPort routing.
function isSandboxMode(): boolean {
  if (typeof window === 'undefined') return false
  return window.location.port === '81'
}

function createSocket(): Socket {
  if (isSandboxMode()) {
    return io(`/?XTransformPort=${TRACE_PORT}`, {
      path: '/socket.io',
      transports: ['polling', 'websocket'],
      upgrade: true,
      rememberUpgrade: true,
      forceNew: true,
      reconnection: true,
      reconnectionAttempts: 20,
      reconnectionDelay: 1000,
      timeout: 30000,
    })
  }
  return io(`http://localhost:${TRACE_PORT}`, {
    path: '/socket.io',
    transports: ['polling', 'websocket'],
    upgrade: true,
    rememberUpgrade: true,
    forceNew: true,
    reconnection: true,
    reconnectionAttempts: 20,
    reconnectionDelay: 1000,
    timeout: 30000,
  })
}

// Load trace history from localStorage
function loadHistory(): TraceResult[] {
  if (typeof window === 'undefined') return []
  try {
    const raw = localStorage.getItem(HISTORY_STORAGE_KEY)
    if (!raw) return []
    const parsed = JSON.parse(raw)
    if (!Array.isArray(parsed)) return []
    return parsed.slice(0, MAX_HISTORY)
  } catch {
    return []
  }
}

function saveHistory(history: TraceResult[]): void {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history.slice(0, MAX_HISTORY)))
  } catch {
    /* localStorage might be full or disabled */
  }
}

interface TraceState {
  // connection
  socket: Socket | null
  connected: boolean
  connectionError: string | null

  // user location
  userLocation: GeoInfo
  userLocationStatus: 'idle' | 'requesting' | 'granted' | 'denied' | 'fallback'
  requestUserLocation: () => void

  // current trace
  trace: TraceResult | null
  isTracing: boolean
  lastError: string | null

  // focus target (when user clicks a hop, the globe flies to it)
  focusTarget: GeoInfo | null
  setFocusTarget: (geo: GeoInfo | null) => void

  // history
  history: TraceResult[]
  clearHistory: () => void
  replayFromHistory: (index: number) => void
  exportTrace: (trace: TraceResult) => void

  // status
  statusMessage: string

  // actions
  initSocket: () => void
  disconnect: () => void
  startTrace: (target: string) => void
  reset: () => void
}

function emptyTrace(target: string): TraceResult {
  return {
    target,
    dnsServers: [],
    hops: [],
    status: 'resolving',
    startedAt: Date.now(),
  }
}

const STATUS_MESSAGES: Record<TraceStatus, string> = {
  idle: 'Idle',
  resolving: 'Resolving DNS…',
  dns: 'Querying DNS resolvers…',
  ssl: 'Performing TLS handshake…',
  traceroute: 'Running real traceroute…',
  done: 'Trace complete',
  error: 'Trace failed',
}

function getGeoEndpoint(): string {
  if (typeof window === 'undefined') return ''
  if (window.location.port === '81') {
    return `/geo?XTransformPort=${TRACE_PORT}`
  }
  return `http://localhost:${TRACE_PORT}/geo`
}

async function fetchIpGeolocation(): Promise<GeoInfo | null> {
  try {
    const res = await fetch(getGeoEndpoint())
    if (!res.ok) return null
    const json = await res.json()
    if (json.error) return null
    return json as GeoInfo
  } catch {
    return null
  }
}

export const useTraceStore = create<TraceState>((set, get) => ({
  socket: null,
  connected: false,
  connectionError: null,

  userLocation: DEFAULT_USER_ORIGIN,
  userLocationStatus: 'idle',

  trace: null,
  isTracing: false,
  lastError: null,

  focusTarget: null,
  setFocusTarget: (geo) => set({ focusTarget: geo }),

  // Always start with empty history to match server-rendered HTML.
  // localStorage is loaded in initSocket() (runs in useEffect, client-only).
  history: [],
  clearHistory: () => {
    saveHistory([])
    set({ history: [] })
  },
  replayFromHistory: (index) => {
    const item = get().history[index]
    if (!item) return
    set({ trace: item, isTracing: false, statusMessage: 'Replaying from history' })
  },
  exportTrace: (trace) => {
    if (typeof window === 'undefined') return
    const blob = new Blob([JSON.stringify(trace, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `netsphere-${trace.target}-${Date.now()}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  },

  statusMessage: 'Idle',

  requestUserLocation: () => {
    if (get().userLocationStatus === 'requesting' || get().userLocationStatus === 'granted') return
    if (typeof window === 'undefined' || !navigator.geolocation) {
      set({ userLocationStatus: 'fallback' })
      fetchIpGeolocation().then((geo) => {
        if (geo) {
          set({ userLocation: geo, userLocationStatus: 'granted' })
        } else {
          set({ userLocationStatus: 'denied' })
        }
      })
      return
    }

    set({ userLocationStatus: 'requesting' })
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const newLocation: GeoInfo = {
          ...get().userLocation,
          lat: pos.coords.latitude,
          lng: pos.coords.longitude,
          city: 'Your location',
        }
        set({ userLocation: newLocation, userLocationStatus: 'granted' })
        fetchIpGeolocation().then((geo) => {
          if (geo) {
            set({
              userLocation: {
                ...geo,
                lat: pos.coords.latitude,
                lng: pos.coords.longitude,
                city: geo.city || 'Your location',
              },
            })
          }
        })
      },
      () => {
        set({ userLocationStatus: 'fallback' })
        fetchIpGeolocation().then((geo) => {
          if (geo) {
            set({ userLocation: geo, userLocationStatus: 'granted' })
          } else {
            set({ userLocationStatus: 'denied' })
          }
        })
      },
      { enableHighAccuracy: false, timeout: 8000, maximumAge: 600000 },
    )
  },

  initSocket: () => {
    if (get().socket) return

    // Load trace history from localStorage (client-only, runs in useEffect
    // after hydration — prevents SSR hydration mismatch).
    if (typeof window !== 'undefined') {
      const stored = loadHistory()
      if (stored.length > 0) {
        set({ history: stored })
      }
    }

    const sock = createSocket()

    sock.on('connect', () => {
      set({ connected: true, connectionError: null })
    })
    sock.on('disconnect', () => {
      set({ connected: false })
    })
    sock.on('connect_error', (err: Error) => {
      set({
        connected: false,
        connectionError: `Cannot reach trace-service on port ${TRACE_PORT}. Make sure it's running. (${err.message})`,
      })
    })

    sock.on('trace:update', (trace: TraceResult) => {
      const wasTracing = get().isTracing
      const isNowDone = trace.status === 'done'
      set({
        trace,
        isTracing: trace.status !== 'done' && trace.status !== 'error',
        statusMessage: STATUS_MESSAGES[trace.status] ?? 'Working…',
        lastError: trace.error ?? null,
      })
      // When a trace completes, push it to history (only once)
      if (wasTracing && isNowDone && trace.hops.length > 0) {
        const newHistory = [trace, ...get().history].slice(0, MAX_HISTORY)
        set({ history: newHistory })
        saveHistory(newHistory)
      }
    })

    sock.on('trace:hop', () => {
      // Hop is already in trace.hops from trace:update
    })

    sock.on('trace:error', (data: { error: string }) => {
      set({
        lastError: data.error,
        isTracing: false,
        statusMessage: 'Trace failed',
        trace: get().trace
          ? { ...get().trace!, status: 'error', error: data.error, finishedAt: Date.now() }
          : null,
      })
    })

    set({ socket: sock })
  },

  disconnect: () => {
    const sock = get().socket
    if (sock) {
      sock.disconnect()
      set({ socket: null, connected: false })
    }
  },

  startTrace: (target) => {
    const sock = get().socket
    if (!sock || !get().connected) {
      set({ lastError: 'Not connected to trace service. Is the trace-service window running?' })
      return
    }
    const cleanTarget = target.trim()
    if (!cleanTarget) return

    set({
      trace: emptyTrace(cleanTarget),
      isTracing: true,
      lastError: null,
      statusMessage: 'Resolving DNS…',
      focusTarget: null,
    })

    sock.emit('trace', { target: cleanTarget })
  },

  reset: () => {
    set({
      trace: null,
      isTracing: false,
      lastError: null,
      statusMessage: 'Idle',
      focusTarget: null,
    })
  },
}))
