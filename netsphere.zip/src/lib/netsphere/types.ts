// Shared types between client and trace-service.

export interface GeoInfo {
  ip: string
  lat: number
  lng: number
  city?: string
  region?: string
  country?: string
  countryCode?: string
  org?: string
  asn?: string
  isp?: string
  timezone?: string
}

export interface Hop {
  index: number
  ip: string | '*'
  hostname?: string
  rtt?: number
  geo?: GeoInfo
  bgp?: {
    asn?: string
    asnName?: string
    asnCountry?: string
    prefix?: string
  }
}

export interface SslInfo {
  protocol: string
  cipher: string
  subjectCn?: string
  issuerCn?: string
  validFrom?: string
  validTo?: string
}

export interface CdnInfo {
  name: string
  detected: boolean
  header?: string
}

export type TraceStatus =
  | 'idle'
  | 'resolving'
  | 'dns'
  | 'ssl'
  | 'traceroute'
  | 'done'
  | 'error'

export interface TraceResult {
  target: string
  resolvedIp?: string
  dnsServers: string[]
  ssl?: SslInfo
  cdn?: CdnInfo
  hops: Hop[]
  finalPing?: number
  serverLocation?: GeoInfo
  security?: {
    hsts?: boolean
    hstsMaxAge?: number
    http2?: boolean
    http3?: boolean
    ipv6?: boolean
    ipv6Address?: string
    openPorts?: { port: number; service: string; open: boolean }[]
  }
  status: TraceStatus
  error?: string
  startedAt: number
  finishedAt?: number
}

// User origin. Will be replaced at runtime with the browser's real geolocation
// (if the user grants permission). Falls back to aip-api.com's IP-based lookup
// if geolocation is denied.
export const DEFAULT_USER_ORIGIN: GeoInfo = {
  ip: '0.0.0.0',
  lat: 40.7128,
  lng: -74.006,
  city: 'Locating…',
  country: '',
  org: 'You',
  isp: 'You',
}

// Convert lat/lng to a 3D vector on a sphere of given radius.
export function latLngToVector3(
  lat: number,
  lng: number,
  radius: number,
): [number, number, number] {
  const phi = (90 - lat) * (Math.PI / 180)
  const theta = (lng + 180) * (Math.PI / 180)
  const x = -radius * Math.sin(phi) * Math.cos(theta)
  const z = radius * Math.sin(phi) * Math.sin(theta)
  const y = radius * Math.cos(phi)
  return [x, y, z]
}

// Color for a hop based on its position in the route — cyan→violet→amber.
export function hopColor(index: number, total: number): string {
  const t = total > 1 ? index / (total - 1) : 0
  if (t < 0.5) {
    const k = t * 2
    const r = Math.round(0x22 + (0xa7 - 0x22) * k)
    const g = Math.round(0xd3 + (0x8b - 0xd3) * k)
    const b = Math.round(0xee + (0xfa - 0xee) * k)
    return `rgb(${r}, ${g}, ${b})`
  } else {
    const k = (t - 0.5) * 2
    const r = Math.round(0xa7 + (0xf5 - 0xa7) * k)
    const g = Math.round(0x8b + (0x9e - 0x8b) * k)
    const b = Math.round(0xfa + (0x0b - 0xfa) * k)
    return `rgb(${r}, ${g}, ${b})`
  }
}

// Haversine great-circle distance between two lat/lng points, in kilometers.
// Used to compute the total geographic distance traveled by the packets.
export function haversineKm(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number,
): number {
  const R = 6371 // Earth radius in km
  const toRad = (d: number) => (d * Math.PI) / 180
  const dLat = toRad(lat2 - lat1)
  const dLng = toRad(lng2 - lng1)
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c
}

// Format a distance in km as a human-readable string.
export function formatDistance(km: number): string {
  if (km < 1) return `${Math.round(km * 1000)} m`
  if (km < 10000) return `${Math.round(km).toLocaleString()} km`
  return `${(km / 1000).toFixed(1)}k km`
}

// Compute the total geographic distance of a trace path.
// Sums the great-circle distance between consecutive geo-located hops.
// Skips private/LAN hops and hops without geolocation.
export function totalPathDistance(
  userLocation: GeoInfo,
  hops: Hop[],
): number {
  const geoPoints: { lat: number; lng: number }[] = [
    { lat: userLocation.lat, lng: userLocation.lng },
  ]
  for (const hop of hops) {
    if (!hop.geo) continue
    if (hop.geo.country === 'LAN') continue
    if (hop.geo.lat === 0 && hop.geo.lng === 0) continue
    geoPoints.push({ lat: hop.geo.lat, lng: hop.geo.lng })
  }
  let total = 0
  for (let i = 1; i < geoPoints.length; i++) {
    total += haversineKm(
      geoPoints[i - 1].lat,
      geoPoints[i - 1].lng,
      geoPoints[i].lat,
      geoPoints[i].lng,
    )
  }
  return total
}
